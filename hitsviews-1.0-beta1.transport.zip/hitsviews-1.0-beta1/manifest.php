<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '286aa2e0a7511d1069c13ed8ed56e5fd',
      'native_key' => 'hitsviews',
      'filename' => 'modNamespace/3812d970bafcac471fae79fff7fb64a3.vehicle',
      'namespace' => 'hitsviews',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '1432b73e67bdfcb66aa393b8b33ba19d',
      'native_key' => 31,
      'filename' => 'modPlugin/1c150d28141d29b6874f9ffee658d777.vehicle',
      'namespace' => 'hitsviews',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4df7195ea162af9be3c80fc930d30cef',
      'native_key' => 1,
      'filename' => 'modCategory/31c7c2cda97d6f5d9e2e25f0236e2fa8.vehicle',
      'namespace' => 'hitsviews',
    ),
  ),
);